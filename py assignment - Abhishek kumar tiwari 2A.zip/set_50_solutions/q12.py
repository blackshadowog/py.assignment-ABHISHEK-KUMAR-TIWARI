s={i*i for i in range(1,11) if i%2==0}
print(s)