s=set()
print(s)