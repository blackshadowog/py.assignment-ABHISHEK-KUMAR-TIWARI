t=(1,2,3)
print(set(t))