t = ()
print(t)