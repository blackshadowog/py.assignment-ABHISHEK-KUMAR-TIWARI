lst = []
print(lst)