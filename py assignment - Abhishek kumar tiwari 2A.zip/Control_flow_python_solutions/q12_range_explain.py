print("range(start,stop,step)")
