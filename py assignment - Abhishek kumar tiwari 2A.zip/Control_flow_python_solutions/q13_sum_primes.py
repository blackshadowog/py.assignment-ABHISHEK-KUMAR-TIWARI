n=int(input())
def p(x):
    if x<2:return False
    for i in range(2,int(x**0.5)+1):
        if x%i==0:return False
    return True
print(sum(i for i in range(n+1) if p(i)))
