d={'a':1,'b':2}
d.pop(min(d))
print(d)