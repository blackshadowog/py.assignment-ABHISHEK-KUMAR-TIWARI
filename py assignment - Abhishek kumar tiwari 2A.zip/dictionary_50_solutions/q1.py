d = {}
print(d)